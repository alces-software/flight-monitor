#!/bin/bash

expected_filesystem_list="udev,tmpfs,iuagsfiuagf"
expectedMem=8
expectedCount=40
